"""
Starter training script.

1. Walk dataset folders:
dataset/
   real/
   screen/

2. Extract features.
3. Standardize with StandardScaler.
4. Train XGBClassifier.
5. Save model.pkl and scaler.pkl.
6. Print cross-validation accuracy.
"""

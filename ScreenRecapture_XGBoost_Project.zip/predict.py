"""
Starter prediction script.

Usage:
python predict.py image.jpg

Load scaler.pkl and model.pkl.
Extract features.
Print probability of SCREEN class.
"""

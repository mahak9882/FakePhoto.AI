"""
Starter feature extraction module.
Implement functions:
- fft_features
- lbp_features
- glcm_features
- hog_features
- extract_features(image_path)
The feature list should concatenate all features into one vector.
"""
